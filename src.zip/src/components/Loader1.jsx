import React from 'react'
import '../styles/Loader1.css'

const Loader1 = () => {
  return (
    <div class="loader"></div>
  )
}

export default Loader1